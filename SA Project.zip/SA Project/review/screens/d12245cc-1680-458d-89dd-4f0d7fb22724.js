var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738218016950.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Introduction"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/d12245cc-1680-458d-89dd-4f0d7fb22724/style-1738218016950.css" />\
      <div class="freeLayout">\
      <div id="s-Group_27" class="group firer ie-background commentable non-processed" customid="Dots menu icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Circle_2" class="path firer click commentable non-processed" customid="Dot-Filled"   datasizewidth="5.98px" datasizeheight="7.93px" dataX="72.93" dataY="702.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="5.98025705218722" height="7.929285127816227" viewBox="72.93155099888696 702.0000000000001 5.98025705218722 7.929285127816227" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Circle_2-d1224" d="M72.93158089239869 705.9646425639082 C72.92424514188082 708.1298762393125 74.2679877823518 709.9195624247487 75.90830736394649 709.9292456683276 C77.55874070415749 709.9389886161184 78.919159138297 708.1432264736121 78.91177815756247 705.9646425639082 C78.91911390808033 703.7994088885041 77.57537126760936 702.0097227030677 75.93505168601465 702.000039459489 C74.28461834580366 701.9902965116981 72.92419991166415 703.7860586542043 72.93158089239869 705.9646425639083 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Circle_2-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Circle_3" class="path firer click commentable non-processed" customid="Dot-Filled"   datasizewidth="5.98px" datasizeheight="7.93px" dataX="61.47" dataY="702.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="5.98025705218725" height="7.929285127816227" viewBox="61.465775499443396 702.0000000000001 5.98025705218725 7.929285127816227" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Circle_3-d1224" d="M61.46580539295511 705.9646425639082 C61.45846964243724 708.1298762393125 62.80221228290823 709.9195624247487 64.44253186450294 709.9292456683276 C66.09296520471393 709.9389886161184 67.45338363885345 708.1432264736121 67.44600265811893 705.9646425639082 C67.4533384086368 703.7994088885041 66.1095957681658 702.0097227030677 64.4692761865711 702.000039459489 C62.8188428463601 701.9902965116981 61.45842441222058 703.7860586542043 61.46580539295511 705.9646425639083 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Circle_3-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Circle_4" class="path firer click commentable non-processed" customid="Dot-Filled"   datasizewidth="5.98px" datasizeheight="7.93px" dataX="50.00" dataY="702.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="5.980257052187068" height="7.929285127816227" viewBox="49.99999999999997 702.0000000000001 5.980257052187068 7.929285127816227" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Circle_4-d1224" d="M50.000029893511694 705.9646425639082 C49.99269414299383 708.1298762393125 51.33643678346478 709.9195624247487 52.97675636505943 709.9292456683276 C54.627189705270375 709.9389886161184 55.98760813940985 708.1432264736121 55.980227158675326 705.9646425639082 C55.987562909193194 703.7994088885041 54.64382026872224 702.0097227030677 53.003500687127584 702.000039459489 C51.353067346916646 701.9902965116981 49.99264891277716 703.7860586542043 50.000029893511694 705.9646425639083 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Circle_4-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Scanner Mode"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="1164.00" dataY="683.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Scanner Mode</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Select_1" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="139.00px" datasizeheight="45.00px" dataX="551.00" dataY="43.00"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Spanish</div></div></div></div></div><select id="s-Select_1-options" class="s-d12245cc-1680-458d-89dd-4f0d7fb22724 dropdown-options" ><option  class="option">English</option>\
      <option selected="selected" class="option">Spanish</option>\
      <option  class="option">French</option></select></div>\
      <div id="s-Select_2" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="139.00px" datasizeheight="45.00px" dataX="730.33" dataY="42.50"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">English</div></div></div></div></div><select id="s-Select_2-options" class="s-d12245cc-1680-458d-89dd-4f0d7fb22724 dropdown-options" ><option selected="selected" class="option">English</option>\
      <option  class="option">Spanish</option>\
      <option  class="option">French</option></select></div>\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="From"   datasizewidth="54.33px" datasizeheight="34.00px" dataX="496.67" dataY="54.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">From</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="to"   datasizewidth="26.33px" datasizeheight="34.00px" dataX="704.00" dataY="54.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">to</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Start Listening"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="1164.00" dataY="541.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Start Listening</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Learn"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="1164.00" dataY="612.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Learn</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;