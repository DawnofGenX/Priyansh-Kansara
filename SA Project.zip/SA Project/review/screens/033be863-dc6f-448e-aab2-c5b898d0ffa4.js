var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738218016950.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-033be863-dc6f-448e-aab2-c5b898d0ffa4" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Computer_Vision"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/033be863-dc6f-448e-aab2-c5b898d0ffa4/style-1738218016950.css" />\
      <div class="freeLayout">\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Narrator Mode"   datasizewidth="138.02px" datasizeheight="29.00px" dataX="1121.00" dataY="674.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Narrator Mode</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="checkbox firer mouseenter mouseleave commentable non-processed checked" customid="Toggle"  datasizewidth="52.00px" datasizeheight="23.55px" dataX="1259.02" dataY="674.00"   value="true"  checked="checked" tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="35.00" dataY="666.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Back</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Detected Text: .........."   datasizewidth="605.21px" datasizeheight="54.00px" dataX="380.39" dataY="52.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Detected Text: ...............................................................................................................<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Select_1" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="139.00px" datasizeheight="45.00px" dataX="551.00" dataY="651.75"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Spanish</div></div></div></div></div><select id="s-Select_1-options" class="s-033be863-dc6f-448e-aab2-c5b898d0ffa4 dropdown-options" ><option  class="option">English</option>\
      <option selected="selected" class="option">Spanish</option>\
      <option  class="option">French</option></select></div>\
      <div id="s-Select_2" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="139.00px" datasizeheight="45.00px" dataX="730.33" dataY="651.25"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">English</div></div></div></div></div><select id="s-Select_2-options" class="s-033be863-dc6f-448e-aab2-c5b898d0ffa4 dropdown-options" ><option selected="selected" class="option">English</option>\
      <option  class="option">Spanish</option>\
      <option  class="option">French</option></select></div>\
      <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="From"   datasizewidth="54.33px" datasizeheight="34.00px" dataX="496.67" dataY="662.75" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">From</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="to"   datasizewidth="26.33px" datasizeheight="34.00px" dataX="704.00" dataY="662.75" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">to</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;