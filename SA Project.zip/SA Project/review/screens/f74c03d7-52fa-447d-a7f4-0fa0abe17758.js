var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738218016950.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-f74c03d7-52fa-447d-a7f4-0fa0abe17758" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Learner "width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/f74c03d7-52fa-447d-a7f4-0fa0abe17758/style-1738218016950.css" />\
      <div class="freeLayout">\
      <div id="s-Button_6" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="35.00" dataY="666.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Back</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="_____ Spanish Words Spoke"   datasizewidth="418.21px" datasizeheight="66.00px" dataX="58.00" dataY="52.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">_____ Spanish Words Spoken Today<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="188.00px" datasizeheight="168.00px" dataX="1106.00" dataY="52.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Select_1" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="300.00px" datasizeheight="45.00px" dataX="1013.00" dataY="644.00"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Change Language</div></div></div></div></div><select id="s-Select_1-options" class="s-f74c03d7-52fa-447d-a7f4-0fa0abe17758 dropdown-options" ><option  class="option">English</option>\
      <option  class="option">Spanish</option>\
      <option  class="option">French</option>\
      <option selected="selected" class="option">Change Language</option></select></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;