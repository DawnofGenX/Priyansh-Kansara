var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738218016950.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-3fc855cd-c57b-4d5a-b20e-f1a57a686cd7" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Settings"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/3fc855cd-c57b-4d5a-b20e-f1a57a686cd7/style-1738218016950.css" />\
      <div class="freeLayout">\
      <div id="s-Button_6" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="35.00" dataY="666.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Back</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Voice Type"   datasizewidth="199.04px" datasizeheight="56.00px" dataX="127.00" dataY="103.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Voice Type</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Change Language model"   datasizewidth="297.04px" datasizeheight="56.00px" dataX="127.00" dataY="228.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Change Language model</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="Text"   datasizewidth="1.00px" datasizeheight="1.00px" dataX="141.00" dataY="281.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Offline Mode"   datasizewidth="188.04px" datasizeheight="56.00px" dataX="127.00" dataY="167.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Offline Mode</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Sign into Google"   datasizewidth="297.04px" datasizeheight="56.00px" dataX="127.00" dataY="294.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">Sign into Google</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Check_1" class="checkbox firer mouseenter mouseleave commentable non-processed checked" customid="Toggle"  datasizewidth="64.00px" datasizeheight="27.55px" dataX="294.04" dataY="167.00"   value="true"  checked="checked" tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Select_1" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="169.00px" datasizeheight="28.00px" dataX="274.04" dataY="103.00"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Male </div></div></div></div></div><select id="s-Select_1-options" class="s-3fc855cd-c57b-4d5a-b20e-f1a57a686cd7 dropdown-options" ><option selected="selected" class="option">Male </option>\
      <option  class="option">Female</option></select></div>\
      <div id="s-Select_2" class="dropdown firer commentable non-processed" customid="Select 1"    datasizewidth="169.00px" datasizeheight="33.00px" dataX="424.04" dataY="223.00"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Model 1</div></div></div></div></div><select id="s-Select_2-options" class="s-3fc855cd-c57b-4d5a-b20e-f1a57a686cd7 dropdown-options" ><option selected="selected" class="option">Model 1</option>\
      <option  class="option">Model 2</option>\
      <option  class="option">Model 3</option></select></div>\
      <div id="s-Text_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Reset Progress"   datasizewidth="297.04px" datasizeheight="56.00px" dataX="127.00" dataY="356.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">Reset Progress</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Send Feedback"   datasizewidth="297.04px" datasizeheight="56.00px" dataX="127.00" dataY="412.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Send Feedback</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;