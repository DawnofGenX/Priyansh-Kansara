	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Button_6", "3fc855cd-c57b-4d5a-b20e-f1a57a686cd7"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "3fc855cd-c57b-4d5a-b20e-f1a57a686cd7"]] = ["Basic button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Check_1", "3fc855cd-c57b-4d5a-b20e-f1a57a686cd7"]] = ""; 

			widgets.rootWidgetMap[["s-Check_1", "3fc855cd-c57b-4d5a-b20e-f1a57a686cd7"]] = ["Toggle", "s-Check_1"]; 

	widgets.descriptionMap[["s-Button_6", "f74c03d7-52fa-447d-a7f4-0fa0abe17758"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "f74c03d7-52fa-447d-a7f4-0fa0abe17758"]] = ["Basic button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Input_3", "033be863-dc6f-448e-aab2-c5b898d0ffa4"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "033be863-dc6f-448e-aab2-c5b898d0ffa4"]] = ["Toggle", "s-Input_3"]; 

	widgets.descriptionMap[["s-Button_6", "033be863-dc6f-448e-aab2-c5b898d0ffa4"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "033be863-dc6f-448e-aab2-c5b898d0ffa4"]] = ["Basic button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Circle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dots menu", "s-Group_27"]; 

	widgets.descriptionMap[["s-Circle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dots menu", "s-Group_27"]; 

	widgets.descriptionMap[["s-Circle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dots menu", "s-Group_27"]; 

	