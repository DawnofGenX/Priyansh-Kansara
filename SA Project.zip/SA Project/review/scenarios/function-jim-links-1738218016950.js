(function(window, undefined) {

  var jimLinks = {
    "3fc855cd-c57b-4d5a-b20e-f1a57a686cd7" : {
      "Button_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "f74c03d7-52fa-447d-a7f4-0fa0abe17758" : {
      "Button_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "033be863-dc6f-448e-aab2-c5b898d0ffa4" : {
      "Button_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Circle_2" : [
        "3fc855cd-c57b-4d5a-b20e-f1a57a686cd7"
      ],
      "Circle_3" : [
        "3fc855cd-c57b-4d5a-b20e-f1a57a686cd7"
      ],
      "Circle_4" : [
        "3fc855cd-c57b-4d5a-b20e-f1a57a686cd7"
      ],
      "Button_1" : [
        "033be863-dc6f-448e-aab2-c5b898d0ffa4"
      ],
      "Button_3" : [
        "f74c03d7-52fa-447d-a7f4-0fa0abe17758"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);